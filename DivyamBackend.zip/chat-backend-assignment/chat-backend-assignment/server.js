const express = require('express');
const http = require('http');
const path = require('path');
const fs = require('fs');
const cors = require('cors');
const multer = require('multer');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const { WebSocketServer } = require('ws');

const PORT = process.env.PORT || 4000;
const JWT_SECRET = process.env.JWT_SECRET || 'chat_assignment_secret_123';
const UPLOAD_DIR = path.join(__dirname, 'uploads');

if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(UPLOAD_DIR));
app.use(express.static(path.join(__dirname, 'public')));

const storage = multer.diskStorage({
  destination: (_, __, cb) => cb(null, UPLOAD_DIR),
  filename: (_, file, cb) => {
    const safeName = file.originalname.replace(/\s+/g, '_');
    cb(null, `${Date.now()}-${safeName}`);
  }
});

const upload = multer({ storage });

const users = [
  { id: 'u1', name: 'alice', password: '123456' },
  { id: 'u2', name: 'bob', password: '123456' },
  { id: 'u3', name: 'carol', password: '123456' }
];

const rooms = new Map();
const connections = new Map(); // userId -> Set<ws>

function createRoom(name, createdBy, members = []) {
  const roomId = uuidv4();
  const room = {
    id: roomId,
    name,
    createdBy,
    members: new Map(members),
    messages: [],
    lastRead: {}
  };
  rooms.set(roomId, room);
  return room;
}

function seedData() {
  const general = createRoom('general', 'u1', [
    ['u1', 'admin'],
    ['u2', 'write'],
    ['u3', 'read']
  ]);

  general.messages.push({
    id: uuidv4(),
    roomId: general.id,
    senderId: 'u1',
    senderName: 'alice',
    messageType: 'text',
    text: 'Welcome to the demo room.',
    fileUrl: null,
    fileName: null,
    mimeType: null,
    createdAt: new Date().toISOString()
  });
}

seedData();

function signToken(user) {
  return jwt.sign({ id: user.id, name: user.name }, JWT_SECRET, { expiresIn: '7d' });
}

function getUserById(userId) {
  return users.find((user) => user.id === userId);
}

function getRoom(roomId) {
  return rooms.get(roomId);
}

function getRole(room, userId) {
  return room.members.get(userId);
}

function isMember(room, userId) {
  return room.members.has(userId);
}

function canWrite(room, userId) {
  const role = getRole(room, userId);
  return role === 'admin' || role === 'write';
}

function isAdmin(room, userId) {
  return getRole(room, userId) === 'admin';
}

function serializeRoom(room, userId) {
  return {
    id: room.id,
    name: room.name,
    role: room.members.get(userId),
    memberCount: room.members.size,
    lastMessage: room.messages[room.messages.length - 1] || null
  };
}

function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;

  if (!token) {
    return res.status(401).json({ message: 'Missing token' });
  }

  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = payload;
    next();
  } catch (error) {
    return res.status(401).json({ message: 'Invalid token' });
  }
}

function sendJson(ws, payload) {
  if (ws.readyState === 1) {
    ws.send(JSON.stringify(payload));
  }
}

function broadcastToUser(userId, payload) {
  const sockets = connections.get(userId);
  if (!sockets) return;

  sockets.forEach((ws) => sendJson(ws, payload));
}

function broadcastToRoom(room, payload, excludeUserId = null) {
  room.members.forEach((_, memberId) => {
    if (memberId !== excludeUserId) {
      broadcastToUser(memberId, payload);
    }
  });
}

app.get('/api/health', (_, res) => {
  res.json({ status: 'ok', port: PORT });
});

app.post('/api/auth/login', (req, res) => {
  const { name, password } = req.body;

  const user = users.find(
    (item) => item.name.toLowerCase() === String(name || '').toLowerCase() && item.password === password
  );

  if (!user) {
    return res.status(401).json({ message: 'Invalid credentials' });
  }

  const token = signToken(user);
  const roomList = Array.from(rooms.values())
    .filter((room) => room.members.has(user.id))
    .map((room) => serializeRoom(room, user.id));

  return res.json({
    token,
    user: { id: user.id, name: user.name },
    rooms: roomList
  });
});

app.get('/api/users', authMiddleware, (_, res) => {
  res.json(users.map(({ password, ...user }) => user));
});

app.get('/api/rooms', authMiddleware, (req, res) => {
  const roomList = Array.from(rooms.values())
    .filter((room) => room.members.has(req.user.id))
    .map((room) => serializeRoom(room, req.user.id));

  res.json(roomList);
});

app.post('/api/rooms', authMiddleware, (req, res) => {
  const { name } = req.body;

  if (!name || !String(name).trim()) {
    return res.status(400).json({ message: 'Room name is required' });
  }

  const room = createRoom(String(name).trim(), req.user.id, [[req.user.id, 'admin']]);
  res.status(201).json(serializeRoom(room, req.user.id));
});

app.post('/api/rooms/:roomId/members', authMiddleware, (req, res) => {
  const { roomId } = req.params;
  const { userId, role } = req.body;
  const room = getRoom(roomId);

  if (!room) {
    return res.status(404).json({ message: 'Room not found' });
  }

  if (!isAdmin(room, req.user.id)) {
    return res.status(403).json({ message: 'Only admin can add or update members' });
  }

  const user = getUserById(userId);
  if (!user) {
    return res.status(404).json({ message: 'User not found' });
  }

  if (!['admin', 'write', 'read'].includes(role)) {
    return res.status(400).json({ message: 'Role must be admin, write, or read' });
  }

  room.members.set(userId, role);

  broadcastToUser(userId, {
    type: 'room_membership_updated',
    room: serializeRoom(room, userId)
  });

  return res.json({
    roomId: room.id,
    userId,
    role
  });
});

app.get('/api/rooms/:roomId/messages', authMiddleware, (req, res) => {
  const room = getRoom(req.params.roomId);

  if (!room) {
    return res.status(404).json({ message: 'Room not found' });
  }

  if (!isMember(room, req.user.id)) {
    return res.status(403).json({ message: 'Not allowed' });
  }

  res.json(room.messages);
});

app.post('/api/uploads', authMiddleware, upload.single('file'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ message: 'File is required' });
  }

  res.status(201).json({
    fileUrl: `/uploads/${req.file.filename}`,
    fileName: req.file.originalname,
    mimeType: req.file.mimetype,
    size: req.file.size
  });
});

app.get('*', (_, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

wss.on('connection', (ws, req) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host}`);
    const token = url.searchParams.get('token');

    if (!token) {
      sendJson(ws, { type: 'error', message: 'Missing token' });
      ws.close();
      return;
    }

    const payload = jwt.verify(token, JWT_SECRET);
    ws.user = payload;
    ws.joinedRooms = new Set();

    if (!connections.has(payload.id)) {
      connections.set(payload.id, new Set());
    }
    connections.get(payload.id).add(ws);

    sendJson(ws, {
      type: 'connected',
      user: { id: payload.id, name: payload.name },
      message: 'WebSocket connected'
    });

    ws.on('message', (raw) => {
      let data;
      try {
        data = JSON.parse(raw.toString());
      } catch (error) {
        sendJson(ws, { type: 'error', message: 'Invalid JSON payload' });
        return;
      }

      const room = data.roomId ? getRoom(data.roomId) : null;

      switch (data.type) {
        case 'join_room': {
          if (!room) {
            sendJson(ws, { type: 'error', message: 'Room not found' });
            return;
          }

          if (!isMember(room, ws.user.id)) {
            sendJson(ws, { type: 'error', message: 'You are not a member of this room' });
            return;
          }

          ws.joinedRooms.add(room.id);
          sendJson(ws, {
            type: 'room_joined',
            room: serializeRoom(room, ws.user.id),
            history: room.messages.slice(-50)
          });

          broadcastToRoom(room, {
            type: 'presence',
            roomId: room.id,
            userId: ws.user.id,
            userName: ws.user.name,
            status: 'online'
          }, ws.user.id);
          return;
        }

        case 'typing': {
          if (!room || !isMember(room, ws.user.id)) {
            sendJson(ws, { type: 'error', message: 'Typing event denied' });
            return;
          }

          broadcastToRoom(room, {
            type: 'typing',
            roomId: room.id,
            userId: ws.user.id,
            userName: ws.user.name,
            isTyping: Boolean(data.isTyping),
            expiresInMs: 3000
          }, ws.user.id);
          return;
        }

        case 'chat_message': {
          if (!room) {
            sendJson(ws, { type: 'error', message: 'Room not found' });
            return;
          }

          if (!isMember(room, ws.user.id)) {
            sendJson(ws, { type: 'error', message: 'You are not a member of this room' });
            return;
          }

          if (!canWrite(room, ws.user.id)) {
            sendJson(ws, { type: 'error', message: 'Read-only member cannot send messages' });
            return;
          }

          const messageType = data.messageType || 'text';
          const message = {
            id: uuidv4(),
            roomId: room.id,
            senderId: ws.user.id,
            senderName: ws.user.name,
            messageType,
            text: data.text || '',
            fileUrl: data.fileUrl || null,
            fileName: data.fileName || null,
            mimeType: data.mimeType || null,
            createdAt: new Date().toISOString()
          };

          const hasText = String(message.text || '').trim().length > 0;
          const hasFile = Boolean(message.fileUrl);

          if (!hasText && !hasFile) {
            sendJson(ws, { type: 'error', message: 'Message text or fileUrl is required' });
            return;
          }

          room.messages.push(message);

          broadcastToRoom(room, {
            type: 'new_message',
            roomId: room.id,
            message
          });
          return;
        }

        case 'mark_read': {
          if (!room || !isMember(room, ws.user.id)) {
            sendJson(ws, { type: 'error', message: 'Read receipt denied' });
            return;
          }

          room.lastRead[ws.user.id] = {
            messageId: data.messageId || null,
            at: new Date().toISOString()
          };

          broadcastToRoom(room, {
            type: 'read_receipt',
            roomId: room.id,
            userId: ws.user.id,
            messageId: data.messageId || null,
            at: room.lastRead[ws.user.id].at
          }, ws.user.id);
          return;
        }

        default:
          sendJson(ws, { type: 'error', message: 'Unsupported event type' });
      }
    });

    ws.on('close', () => {
      const userSockets = connections.get(ws.user.id);
      if (userSockets) {
        userSockets.delete(ws);
        if (userSockets.size === 0) {
          connections.delete(ws.user.id);
        }
      }

      ws.joinedRooms.forEach((roomId) => {
        const room = getRoom(roomId);
        if (!room) return;
        broadcastToRoom(room, {
          type: 'presence',
          roomId,
          userId: ws.user.id,
          userName: ws.user.name,
          status: 'offline'
        }, ws.user.id);
      });
    });
  } catch (error) {
    sendJson(ws, { type: 'error', message: 'Authentication failed' });
    ws.close();
  }
});

server.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
  console.log('Demo users: alice / 123456, bob / 123456, carol / 123456');
});

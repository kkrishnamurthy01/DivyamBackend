# Chat Backend Assignment Solution (Task 2)

This project solves **Task 2** from the Backend / ML Assignment.

## Features
- WebSocket based chat transport
- Text, image, audio, and document message support
- Typing indicator
- Read receipt event
- Role based access: `admin`, `write`, `read`
- REST APIs for login, room management, and file upload
- Small frontend page for demo/testing

## Tech Stack
- Node.js
- Express
- ws (WebSocket server)
- Multer (file upload)
- JWT (simple authentication)

## Install
```bash
npm install
```

## Run
```bash
npm start
```

Server runs at:
```bash
http://localhost:4000
```

## Demo users
- alice / 123456
- bob / 123456
- carol / 123456

## Default role setup in `general` room
- alice = admin
- bob = write
- carol = read

## REST APIs
### Login
```http
POST /api/auth/login
Content-Type: application/json

{
  "name": "alice",
  "password": "123456"
}
```

### Get rooms
```http
GET /api/rooms
Authorization: Bearer <token>
```

### Create room
```http
POST /api/rooms
Authorization: Bearer <token>
Content-Type: application/json

{
  "name": "project-room"
}
```

### Add/update member
```http
POST /api/rooms/:roomId/members
Authorization: Bearer <token>
Content-Type: application/json

{
  "userId": "u2",
  "role": "write"
}
```

### Get message history
```http
GET /api/rooms/:roomId/messages
Authorization: Bearer <token>
```

### Upload file
Use `multipart/form-data` with field name `file`.

## WebSocket events from client
### Join room
```json
{
  "type": "join_room",
  "roomId": "ROOM_ID"
}
```

### Send typing event
```json
{
  "type": "typing",
  "roomId": "ROOM_ID",
  "isTyping": true
}
```

### Send message
```json
{
  "type": "chat_message",
  "roomId": "ROOM_ID",
  "messageType": "text",
  "text": "hello"
}
```

### Send file message
```json
{
  "type": "chat_message",
  "roomId": "ROOM_ID",
  "messageType": "document",
  "text": "Please check this file",
  "fileUrl": "/uploads/sample.pdf",
  "fileName": "sample.pdf",
  "mimeType": "application/pdf"
}
```

### Mark read
```json
{
  "type": "mark_read",
  "roomId": "ROOM_ID",
  "messageId": "MESSAGE_ID"
}
```

## Architecture Answers
### a) What are you using for implementing WebSockets?
I used the `ws` library in Node.js. Express handles REST APIs and `ws` handles real-time message delivery over a persistent socket connection.

### b) How would you support other message types like audio, documents, etc?
Files are uploaded using Multer and stored in the `uploads` folder. The chat message stores metadata such as `messageType`, `fileUrl`, `fileName`, and `mimeType`. In production, the files should be stored in object storage like S3 or Cloudinary.

### c) How do we check if someone is typing?
The client sends a lightweight `typing` event over WebSocket. The server broadcasts it to other members in that room with a short expiry time. This event is not stored permanently.

### d) How can we separate the Admin, Read, or Write members in the group?
Each room has a member-to-role mapping. `admin` can manage members, `write` can send messages, and `read` can only view messages. Every WebSocket action and REST action checks the user role before allowing the action.

## Production improvements
- Replace in-memory data with PostgreSQL / MongoDB
- Store files in S3
- Add Redis pub/sub for multi-server scale
- Add message pagination and delivery acknowledgements
- Add refresh tokens and stronger auth
